clear;
close all;
path(path,genpath('..\stack'));
load depth1.dat;
load depth2.dat;
load depth3.dat;
load depth4.dat;
load depth5.dat;
load station.dat;

profile2=load('step2_profile.txt');
output='Figure2.eps';
filename='.\';

len1=size(depth1);
len2=size(depth2);
len3=size(depth3);
len4=size(depth4);
len5=size(depth5);

for i =1:len5(1)
    hh5=scatter(depth5(i,2),depth5(i,1),'o');
    set(hh5,'markerfacecolor','b','markeredgecolor','b','markerfaceAlpha',0.5);
end
hold on
for i =1:len4(1)
    hh4=scatter(depth4(i,2),depth4(i,1),'o');
    set(hh4,'markerfacecolor','m','markeredgecolor','m','markerfaceAlpha',0.5);
end
hold on
for i =1:len3(1)
    hh3=scatter(depth3(i,2),depth3(i,1),'o');
    set(hh3,'markerfacecolor','g','markeredgecolor','g','markerfaceAlpha',0.5);
end
hold on
for i =1:len2(1)
    hh2=scatter(depth2(i,2),depth2(i,1),'o');
    set(hh2,'markerfacecolor',[0.9 0.5 0],'markeredgecolor',[0.9 0.5 0],'markerfaceAlpha',0.5);
end
hold on
for i =1:len1(1)
    hh1=scatter(depth1(i,2),depth1(i,1),'o');
    set(hh1,'markerfacecolor','r','markeredgecolor','r','markerfaceAlpha',0.5);
end
hold on
hhe2=plot(profile2(:,1),profile2(:,2),'-','color','k','LineWidth',2);
hold on
hh0=plot(station(:,2),station(:,1),'^','markerfacecolor','b','markeredgecolor','k');
hold on
hh=[hhe2,hh0,hh1,hh2,hh3,hh4,hh5];
xlim([-2,12]);
ylim([-3,3]);
set(gca,'Fontname','Arial','Fontsize',18,'Fontweight','bold','Linewidth',2);
tt=legend(hh,'Profile','Station','50km','100km','120km','150km','200km');
set(tt,'Fontname','Arial','Fontsize',13);
xlabel('Longitude (degree)','Fontname','Arial','Fontsize',18,'Fontweight','bold');
ylabel('Latitude (degree)','Fontname','Arial','Fontsize',18,'Fontweight','bold');

set(gcf,'Position',[0,150,800,500]);

outputname=strcat(filename,output);
print(gcf,'-depsc',outputname);

% zone=utmzone(0,6);
% [la,lo]=utmzone(zone);
% la
% lo
% zone