%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Plot CCP stacking section with bin size and RF numbers at chosen depth
%
% Inputs (parameters set in binr_vary_scan_n.inp):
%
% 1. outfile    -   output file name, no prefix and postfix 
%                   e.g. stack_*.dat, *_yb.dat, *_num.dat
% 2. xlenp      -   profile length (km)
% 3. npt        -   output number of time samples in each trace
% 4. dx         -   the spacing between bins along the profile (km)
% 5. dt         -   time interval (s)
% 6. noutd      -   output number in ninw
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function ccpstack_image_plot


clear all
close all
path(path,genpath('..\stack'));


%% Input parameters
outfile = 'step2';
xlenp = 700;
npt = 2401;
dx = 2;     
dt = 0.05;   
noutd = 5;
numbin = xlenp/dx+1;
timelen = (npt-1)*dt;
x = 0:dx:xlenp;
t = 0:dt:timelen;


%% read in data files
fid=fopen(['stack_',outfile,'.dat'],'r');
stack=fread(fid,[npt,numbin],'float'); 
fclose(fid);
fid=fopen([outfile,'_num.dat'],'r');
a=fread(fid,[numbin,noutd],'float');
fclose(fid);
fid=fopen([outfile,'_yb.dat'],'r');
b=fread(fid,[numbin,noutd],'float'); 
fclose(fid);


%% plot CCP stacking section with parameters including RF numbers used in each bin and half bin width at chosen depth
figure;

imagesc(x,t,stack);ylim([0 15]);caxis([-0.05 0.05]);
xlabel('Distance (km)','FontSize',14);
ylabel('Time (s)','FontSize',14);
set(gca,'Fontname','Arial','Fontsize',14,'Fontweight','bold','Linewidth',1);
set(gcf,'Position',[0,150,1000,400]);
colormap(jet);
bb=colorbar;
set(bb,'Ticks',[-0.08:0.02:0.08],'Linewidth',1);

print(gcf,'-depsc','Figure4.eps');
end
