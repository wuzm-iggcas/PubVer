clear; 
close all;
path(path,genpath('..\stack'));

%% Input and Output Setting
outfile = 'step2';
output='Figure3.eps';
filename='.\';


xlenp  =  700;
npt    =  2401;
dx     =  2;
dt     =  0.05;
noutd  =  5;
numbin = xlenp/dx+1;
timelen = (npt-1)*dt;
x = 0:dx:xlenp;
t = 0:dt:timelen;


%% read in data files
fid=fopen([outfile,'_num.dat'],'r');
a=fread(fid,[numbin,noutd],'float'); 
fclose(fid);
fid=fopen([outfile,'_yb.dat'],'r');
b=fread(fid,[numbin,noutd],'float'); 
fclose(fid);


%% plot RF numbers used in each bin and half bin width at chosen depths
figure;

%plot Depth1
subplot(5,1,1)
y11=a(:,1);y21=b(:,1); % plot the parameters at the first chosen depth
[AX,H1,H2]=plotyy(x,y11,x,y21,'plot');
set(AX(1),'XColor','k','YColor',[0.1 0.2 0.8],'YLim',[min(y11)-5 max(y11)+5],'XLim',[0 xlenp],'linewidth',1);
hold on;
XL=get(AX(1),'xlim');YL=get(AX(1),'ylim');
plot(XL,[YL(2),YL(2)],'k','linewidth',1);
box off
set(AX(2),'XColor','k','YColor',[0.9 0.2 0.0],'YLim',[min(y21)-5 max(y21)+5],'XLim',[0 xlenp],'linewidth',1,'fontsize',12,'fontweight','bold'); 
HH1=get(AX(1),'Ylabel');
set(HH1,'String','No. of RF','color',[0.1 0.2 0.8],'fontsize',12,'fontname','Arial','fontweight','bold');
HH2=get(AX(2),'Ylabel');
set(HH2,'String','Half Ybin (km)','color',[0.9 0.2 0.0],'fontsize',12,'fontname','Arial','fontweight','bold');
set(H1,'color',[0.1 0.2 0.8],'LineWidth',2);
set(H2,'color',[0.9 0.2 0.0],'LineWidth',2);
title('Parameters at 50 km depth','fontsize',12,'fontname','Arial','fontweight','bold')
set(gca,'Fontname','Arial','Fontsize',12,'Fontweight','bold');

%plot Depth2
subplot(5,1,2)
y12=a(:,2);y22=b(:,2); % plot the parameters at the second chosen depth
[AX,H1,H2]=plotyy(x,y12,x,y22,'plot');
set(AX(1),'XColor','k','YColor',[0.1 0.2 0.8],'YTick',[20:20:80],'XLim',[0 xlenp],'linewidth',1);
hold on;
XL=get(AX(1),'xlim');YL=get(AX(1),'ylim');
plot(XL,[YL(2),YL(2)],'k','linewidth',1);
box off
set(AX(2),'XColor','k','YColor',[0.9 0.2 0.0],'YLim',[min(y22)-2 max(y22)+2],'XLim',[0 xlenp],'linewidth',1,'fontsize',12,'fontweight','bold');
HH1=get(AX(1),'Ylabel');
set(HH1,'String','No. of RF','color',[0.1 0.2 0.8],'fontsize',12,'fontname','Arial','fontweight','bold');
HH2=get(AX(2),'Ylabel');
set(HH2,'String','Half Ybin (km)','color',[0.9 0.2 0.0],'fontsize',12,'fontname','Arial','fontweight','bold');
set(H1,'color',[0.1 0.2 0.8],'LineWidth',2);
set(H2,'color',[0.9 0.2 0.0],'LineWidth',2);
title('Parameters at 100 km depth','fontsize',12,'fontname','Arial','fontweight','bold')
set(gca,'Fontname','Arial','Fontsize',12,'Fontweight','bold');

%plot Depth3
subplot(5,1,3)
y13=a(:,3);y23=b(:,3); % plot the parameters at the third chosen depth
[AX,H1,H2]=plotyy(x,y13,x,y23,'plot');
set(AX(1),'XColor','k','YColor',[0.1 0.2 0.8],'YTick',[20:20:80],'XLim',[0 xlenp],'linewidth',1);
hold on;
XL=get(AX(1),'xlim');YL=get(AX(1),'ylim');
plot(XL,[YL(2),YL(2)],'k','linewidth',1);
box off
set(AX(2),'XColor','k','YColor',[0.9 0.2 0.0],'YLim',[min(y23)-2 max(y23)+2],'XLim',[0 xlenp],'linewidth',1,'fontsize',12,'fontweight','bold');
HH1=get(AX(1),'Ylabel');
set(HH1,'String','No. of RF','color',[0.1 0.2 0.8],'fontsize',12,'fontname','Arial','fontweight','bold');
HH2=get(AX(2),'Ylabel');
set(HH2,'String','Half Ybin (km)','color',[0.9 0.2 0.0],'fontsize',12,'fontname','Arial','fontweight','bold');
set(H1,'color',[0.1 0.2 0.8],'LineWidth',2);
set(H2,'color',[0.9 0.2 0.0],'LineWidth',2);
title('Parameters at 120 km depth','fontsize',12,'fontname','Arial','fontweight','bold')
set(gca,'Fontname','Arial','Fontsize',12,'Fontweight','bold');

%plot Depth4
subplot(5,1,4)
y14=a(:,4);y24=b(:,4); % plot the parameters at the fourth chosen depth
[AX,H1,H2]=plotyy(x,y14,x,y24,'plot');
set(AX(1),'XColor','k','YColor',[0.1 0.2 0.8],'YTick',[10:20:70],'XLim',[0 xlenp],'linewidth',1);
hold on;
XL=get(AX(1),'xlim');YL=get(AX(1),'ylim');
plot(XL,[YL(2),YL(2)],'k','linewidth',1);
box off
set(AX(2),'XColor','k','YColor',[0.9 0.2 0.0],'YTick',[min(y24)-2:1:max(y24)+2],'XLim',[0 xlenp],'linewidth',1,'fontsize',12,'fontweight','bold');
HH1=get(AX(1),'Ylabel');
set(HH1,'String','No. of RF','color',[0.1 0.2 0.8],'fontsize',12,'fontname','Arial','fontweight','bold');
HH2=get(AX(2),'Ylabel');
set(HH2,'String','Half Ybin (km)','color',[0.9 0.2 0.0],'fontsize',12,'fontname','Arial','fontweight','bold');
set(H1,'color',[0.1 0.2 0.8],'LineWidth',2);
set(H2,'color',[0.9 0.2 0.0],'LineWidth',2);
title('Parameters at 150 km depth','fontsize',12,'fontname','Arial','fontweight','bold')
set(gca,'Fontname','Arial','Fontsize',12,'Fontweight','bold');

%plot Depth5
subplot(5,1,5)
y15=a(:,5);y25=b(:,5); % plot the parameters at the fifth chosen depth
[AX,H1,H2]=plotyy(x,y15,x,y25,'plot');
set(AX(1),'XColor','k','YColor',[0.1 0.2 0.8],'YTick',[20:20:80],'XLim',[0 xlenp],'linewidth',1);
hold on;
XL=get(AX(1),'xlim');YL=get(AX(1),'ylim');
plot(XL,[YL(2),YL(2)],'k','linewidth',1);
box off
set(AX(2),'XColor','k','YColor',[0.9 0.2 0.0],'YLim',[min(y25)-2 max(y25)+2],'XLim',[0 xlenp],'linewidth',1,'fontsize',12,'fontweight','bold');
HH1=get(AX(1),'Ylabel');
set(HH1,'String','No. of RF','color',[0.1 0.2 0.8],'fontsize',12,'fontname','Arial','fontweight','bold');
HH2=get(AX(2),'Ylabel');
set(HH2,'String','Half Ybin (km)','color',[0.9 0.2 0.0],'fontsize',12,'fontname','Arial','fontweight','bold');
set(H1,'color',[0.1 0.2 0.8],'LineWidth',2);
set(H2,'color',[0.9 0.2 0.0],'LineWidth',2);
title('Parameters at 200 km depth','fontsize',12,'fontname','Arial','fontweight','bold')
set(gca,'Fontname','Arial','Fontsize',12,'Fontweight','bold');
xlabel('Distance (km)','Fontname','Arial','Fontsize',14,'Fontweight','bold');

set(gcf,'Position',[10,50,800,800]);

outputname=strcat(filename,output);
print(gcf,'-depsc',outputname);
