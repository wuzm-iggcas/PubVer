%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Plot migration image
%
% Inputs (parameters set in hdpmig.in):
%
% 1. filename - output migration image data file
% 2. depth    - imaging depth (km)
% 3. prolen   - profile lengh (km)
% 4. dx       - trace interval (km)
% 5. dz       - depth interval, km per grid
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function migration_image_plot

clear all;
close all;
%path(path,genpath('../poststack'));

inputfile1='psdm_step3_taper003_0p50.dat';
inputfile2='psdm_step3_taper003_0p40.dat';
inputfile3='psdm_step3_taper003_0p35.dat';
inputfile4='psdm_step3_taper003_0p30.dat';

% Z 
depth=300; % imaging depth (km)
dz=0.5; % depth interval, km per grid along Z
% X
prolen=700; % profile length
dx=2; % trace interval, km per grid along X

nz=depth/dz; % depth number
nx=prolen/dx+1; % trace number


%% Read Data
fid=fopen(inputfile1,'r');
a1=fread(fid,[nz,nx],'float'); 
fclose(fid);
fid=fopen(inputfile2,'r');
a2=fread(fid,[nz,nx],'float'); 
fclose(fid);
fid=fopen(inputfile3,'r');
a3=fread(fid,[nz,nx],'float'); 
fclose(fid);
fid=fopen(inputfile4,'r');
a4=fread(fid,[nz,nx],'float'); 
fclose(fid);


%% Plot Migrated Images
figure;
amin=-0.5;
amax=0.5;
howdeep=200;

subplot(2,2,1);
imagesc((0:dx:prolen),(dz:dz:depth),a1);
caxis([amin,amax]);
bb=colorbar;
set(bb,'Ticks',[-0.5:0.2:0.5],'Linewidth',1);
ylim([0 howdeep]);
set(gca,'Fontname','Arial','Fontsize',14,'Fontweight','bold');
ylabel('Depth (km)','fontsize',14,'Fontname','Arial','FontWeight','bold');
xlabel('Distance (km)','fontsize',14,'Fontname','Arial','FontWeight','bold');
title('Taper: 0.03-0.5 Hz','Fontsize',10,'Fontname','Arial','FontWeight','bold');
set(gca,'Fontname','Arial','Fontsize',14,'Fontweight','bold','Linewidth',1);

subplot(2,2,2);
imagesc((0:dx:prolen),(dz:dz:depth),a2);
caxis([amin,amax]);
bb=colorbar;
set(bb,'Ticks',[-0.5:0.2:0.5],'Linewidth',1);
ylim([0 howdeep]);
set(gca,'Fontname','Arial','Fontsize',14,'Fontweight','bold');
ylabel('Depth (km)','fontsize',14,'Fontname','Arial','FontWeight','bold');
xlabel('Distance (km)','fontsize',14,'Fontname','Arial','FontWeight','bold');
title('Taper: 0.03-0.4 Hz','Fontsize',10,'Fontname','Arial','FontWeight','bold');
set(gca,'Fontname','Arial','Fontsize',14,'Fontweight','bold','Linewidth',1);

subplot(2,2,3);
imagesc((0:dx:prolen),(dz:dz:depth),a3);
caxis([amin,amax]);
bb=colorbar;
set(bb,'Ticks',[-0.5:0.2:0.5],'Linewidth',1);
ylim([0 howdeep]);
set(gca,'Fontname','Arial','Fontsize',14,'Fontweight','bold');
ylabel('Depth (km)','fontsize',14,'Fontname','Arial','FontWeight','bold');
xlabel('Distance (km)','fontsize',14,'Fontname','Arial','FontWeight','bold');
title('Taper: 0.03-0.35 Hz','Fontsize',10,'Fontname','Arial','FontWeight','bold');
set(gca,'Fontname','Arial','Fontsize',14,'Fontweight','bold','Linewidth',1);

subplot(2,2,4);
imagesc((0:dx:prolen),(dz:dz:depth),a4);
caxis([amin,amax]);
bb=colorbar;
set(bb,'Ticks',[-0.5:0.2:0.5],'Linewidth',1);
ylim([0 howdeep]);
set(gca,'Fontname','Arial','Fontsize',14,'Fontweight','bold');
ylabel('Depth (km)','fontsize',14,'Fontname','Arial','FontWeight','bold');
xlabel('Distance (km)','fontsize',14,'Fontname','Arial','FontWeight','bold');
title('Taper: 0.03-0.3 Hz','Fontsize',10,'Fontname','Arial','FontWeight','bold');
set(gca,'Fontname','Arial','Fontsize',14,'Fontweight','bold','Linewidth',1);

set(gcf,'Position',[0,100,1400,600]);

colormap(jet);

print(gcf,'-depsc','Figure5.eps');
end


