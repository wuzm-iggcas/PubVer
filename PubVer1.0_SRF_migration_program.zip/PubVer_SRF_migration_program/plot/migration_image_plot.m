%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Plot migration image
%
% Inputs (parameters set in hdpmig.in):
%
% 1. filename - output migration image data file
% 2. depth    - imaging depth (km)
% 3. prolen   - profile lengh (km)
% 4. dx       - trace interval (km)
% 5. dz       - depth interval, km per grid
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function migration_image_plot

clear all
close all
path(path,genpath('../poststack'));

filename='psdm_NEiran_f1_dt01_eqz_s.dat';
% Z 
depth=400; % imaging depth (km)
dz=0.5; % depth interval, km per grid along Z
% X
prolen=800; % profile length
dx=2; % trace interval, km per grid along X

nz=depth/dz; % depth number
nx=prolen/dx+1; % trace number

fid=fopen(filename,'r');
a=fread(fid,[nz,nx],'float'); % output image size (nz,nx): 800 *351
fclose(fid);

figure;
subplot(3,1,2:3);
imagesc((0:dx:prolen),(dz:dz:depth),a);
colorbar;caxis([-0.2,0.2]);
ylim([0 200]);
ylabel('depth (km)','fontsize',14);
xlabel('distance (km)','fontsize',14);
title('frequency: 0.03-1.0 Hz','fontsize',14);

print(gcf,'-depsc','PSDMImage.eps');
end


