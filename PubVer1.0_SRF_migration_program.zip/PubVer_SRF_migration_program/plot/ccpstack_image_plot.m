%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Plot CCP stacking section with bin size and RF numbers at chosen depth
%
% Inputs (parameters set in binr_vary_scan_n.inp):
%
% 1. outfile    -   output file name, no prefix and postfix 
%                   e.g. stack_*.dat, *_yb.dat, *_num.dat
% 2. xlenp      -   profile length (km)
% 3. npt        -   output number of time samples in each trace
% 4. dx         -   the spacing between bins along the profile (km)
% 5. dt         -   time interval (s)
% 6. noutd      -   output number in ninw
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function ccpstack_image_plot
%%
clear all
close all
path(path,genpath('../stack'));
%% Input parameters
outfile = 'NEiran_f1_dt01_eqz_s';
xlenp = 800;
npt = 1001;
dx = 2;     
dt = 0.1;   
noutd = 5;
numbin = xlenp/dx+1;
timelen = (npt-1)*dt;
x = 0:dx:xlenp;
t = 0:dt:timelen;
%% read in data files
fid=fopen(['stack_',outfile,'.dat'],'r');
stack=fread(fid,[npt,numbin],'float'); % output data size in each stacked RF file: 1001*351
fclose(fid);
fid=fopen([outfile,'_num.dat'],'r');
a=fread(fid,[numbin,noutd],'float'); % output data size in *num: 351*5
fclose(fid);
fid=fopen([outfile,'_yb.dat'],'r');
b=fread(fid,[numbin,noutd],'float'); % output data size in *yb: 351*5
fclose(fid);
%% plot CCP stacking section with parameters including RF numbers used in each bin and half bin width at chosen depth
figure;

% plot parameters
subplot(4,1,1);
y1=a(:,1);y2=b(:,1); % plot the parameters at the first chosen depth
[AX,H1,H2]=plotyy(x,y1,x,y2,'plot');
set(AX(1),'XColor','k','YColor','b','YLim',[0 max(y1)+2],'XLim',[0 xlenp],'linewidth',1);
hold on;
XL=get(AX(1),'xlim');YL=get(AX(1),'ylim');
plot(XL,[YL(2),YL(2)],'k','linewidth',1);
box off
set(AX(2),'XColor','k','YColor','r','YLim',[28 32],'XLim',[0 xlenp],'linewidth',1);
HH1=get(AX(1),'Ylabel');
set(HH1,'String','RF number','color','b','fontsize',14);
HH2=get(AX(2),'Ylabel');
set(HH2,'String','half bin width (km)','color','r','fontsize',14);
set(H1,'color','b','LineWidth',2);
set(H2,'color','r','LineWidth',2);
title('parameters at depth of 49 km','fontsize',14)

% plot CCP stacking section
subplot(3,1,2:3);
imagesc(x,t,stack);ylim([0 15]);caxis([-0.05 0.05]);
xlabel('distance (km)','FontSize',14);
ylabel('time (s)','FontSize',14);
title('CCP stacking section','FontSize',14)

print(gcf,'-depsc','CCPStackingSection.eps');
end
