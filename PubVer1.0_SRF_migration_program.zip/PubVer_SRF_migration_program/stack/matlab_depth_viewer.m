load depth1.dat;
load depth2.dat;
load depth3.dat;
load depth4.dat;
load depth5.dat;
load station.dat;
hold on
hh0=plot(station(:,2),station(:,1),'^');
hold on
%%dimensions of depth1.dat (e.g. 54 multiply 4)
len1=size(depth1) ;
len2=size(depth2);
len3=size(depth3);
len4=size(depth4);
len5=size(depth5);
for i =1:len1(1)
    hh1=plot(depth1(i,2),depth1(i,1),'o');
    set(hh1,'markerfacecolor','r');
end
hold on
for i =1:len2(1)
    hh2=plot(depth2(i,2),depth2(i,1),'o');
    set(hh2,'markerfacecolor','y');
end
hold on
for i =1:len3(1)
    hh3=plot(depth3(i,2),depth3(i,1),'o');
    set(hh3,'markerfacecolor','g');
end
hold on
for i =1:len4(1)
    hh4=plot(depth4(i,2),depth1(i,1),'o');
    set(hh4,'markerfacecolor','m');
end
hold on
for i =1:len5(1)
    hh5=plot(depth5(i,2),depth5(i,1),'o');
    set(hh5,'markerfacecolor','b');
end
hold on
hh=[hh0,hh1,hh2,hh3,hh4,hh5];
xlim([50,70])
legend(hh,'station','49km','100km','153km','207km','243km')
zone=utmzone(34,59)
[la,lo]=utmzone(zone);
la
lo