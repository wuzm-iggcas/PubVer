clc;
clear;
% close all;
%This program is used to plot the iamge in the  profile
% cd '/home/xuwang/code/stack/stack_result/ncisp6/gc0_55/gc28-92_baz330-420';
%inw20cw
%read the data
figure(2)
c1=851*1;
c=851*1;
dx=2;
dd=2;
a=0.1;
% fid=fopen('stack_sc2_inw20cw_az90_yb5-100vnt100_xb100_dx2_norm0_f2p5.dat','r');
% fid=fopen('sc2_az160_dx2_norm0_f5_f02.dat','r');
% stack=fread(fid,[1001 c*1],'real*4');
% fclose(fid);
% stack1t_f04=stack;
% fid=fopen('sc2_az160_dx2_norm0_f5_f04.dat','r');
% stack=fread(fid,[1001 c*1],'real*4');
% fclose(fid);
% stack1t_f06=stack;
% fid=fopen('sc2_az160_dx2_norm0_f5_f06.dat','r');
% stack=fread(fid,[1001 c*1],'real*4');
% fclose(fid);
% stack1t_f1=stack;
% fid=fopen('sc2_az160_dx2_norm0_f5_f08.dat','r');
% stack=fread(fid,[1001 c*1],'real*4');
% fclose(fid);
% stack1t_f1p4=stack;
% fid=fopen('sc2_az160_dx2_norm0_f5_f1.dat','r');
% stack=fread(fid,[1001 c*1],'real*4');
% fclose(fid);
% stack1t_f2=stack;
% fid=fopen('sc2_az160_dx2_norm0_f5_f1p5.dat','r');
% stack=fread(fid,[1001 c*1],'real*4');
% fclose(fid);
% stack1t_f5=stack;
% fid=fopen('sc2_az160_dx2_norm0_f5_f2.dat','r');
% stack=fread(fid,[1001 c*1],'real*4');
% fclose(fid);
% stack1t_f5_nofil=stack;%1a
% fid=fopen('stack_sc3_az70_yb100vnt1_xb5_dx2_norm0_f04_gc28-92_baz0-360.dat','r');
% stack=fread(fid,[1001 c1*1],'real*4');
% fclose(fid);
% stack1t_f02_kk=stack;
fid=fopen('sc3_az65_dx2_norm0_f3_1_001_eqz_SsPp_profile.txt','r');
pro=fscanf(fid,'%f');
fclose(fid);

hang2=size(pro);   
hang2=hang2(1);




fid=fopen('stack_sc3_az65_dx2_norm0_f3_1_001_eqz_SsPp.dat','r');
stack=fread(fid,[1001 c1*1],'real*4');
fclose(fid);
stack1t_f03_kk=stack;
% fid=fopen('stack_sc3_az70_yb100vnt1_xb5_dx2_norm0_f1_gc28-92_baz0-360.dat','r');
% stack=fread(fid,[1001 c1*1],'real*4');
% fclose(fid);
% stack1t_f05_kk=stack;
% % % % % fid=fopen('stack_isp6taz135_yb25-60vnt200_xb100_dx5_norm0_f07_gc28-92_baz330-420.dat','r');
% % % % % stack=fread(fid,[1001 c1*1],'real*4');
% % % % % fclose(fid);
% % % % % stack1t_f07_kk=stack;
% % % % % fid=fopen('stack_isp6taz135_yb25-60vnt200_xb100_dx5_norm0_f1_gc28-92_baz330-420.dat','r');
% % % % % stack=fread(fid,[1001 c1*1],'real*4');
% % % % % fclose(fid);
% % % % % stack1t_f1_kk=stack;
% % % % % fid=fopen('stack_isp6taz135_yb25-60vnt200_xb100_dx5_norm0_f2p5_gc28-92_baz330-420.dat','r');
% % % % % stack=fread(fid,[1001 c1*1],'real*4');
% % % % % fclose(fid);
% % % % % stack1t_f2p5_kk=stack;
% fid=fopen('sc2_baz270_360_az160_dx2_norm0_f5_05_003_eqt.dat','r');
% stack=fread(fid,[1001 c*1],'real*4');
% fclose(fid);
% stack1t_f5_kt=stack;
% % % % beg=21;
% % % % end1=101;
% % % % stasum02=sum(stack1t_f02_kk(1:1001,beg:end1)')./(end1-beg+1);
% % % % stasum03=sum(stack1t_f03_kk(1:1001,beg:end1)')./(end1-beg+1);
% % % % stasum05=sum(stack1t_f05_kk(1:1001,beg:end1)')./(end1-beg+1);
% % % % stasum07=sum(stack1t_f07_kk(1:1001,beg:end1)')./(end1-beg+1);
% % % % stasum1=sum(stack1t_f1_kk(1:1001,beg:end1)')./(end1-beg+1);
% % % % stasum2p5=sum(stack1t_f2p5_kk(1:1001,beg:end1)')./(end1-beg+1);
% % % % 
% % % % % subplot(211)
% % % % hold on
% % % % % plot(300:700,stasum(300:700),'m');
% % % % plotimag_iz_red([stasum02(301:801)' zeros(501,1)],1,100:5:105,(300:800).*0.1,a);
% % % % 
% % % % plotimag_iz_red([stasum03(301:801)' zeros(501,1)],1,70:5:75,(300:800).*0.1,a);
% % % % plotimag_iz_red([stasum05(301:801)' zeros(501,1)],1,40:5:45,(300:800).*0.1,a);
% % % % plotimag_iz_red([stasum07(301:801)' zeros(501,1)],1,10:5:15,(300:800).*0.1,a);
% % % % plotimag_iz_red([stasum1(301:801)' zeros(501,1)],1,-20:5:-15,(300:800).*0.1,a);
% % % % plotimag_iz_red([stasum2p5(301:801)' zeros(501,1)],1,-50:5:-45,(300:800).*0.1,a);
% % % % set(gca,'Ydir','normal');
% % % % axis([36.5 75.05 -70 130]);
% cord=load('sc2_az160_dx2_norm0_f2_f1_eqr_profile.txt');
% fid=fopen('sc2_az160_dx2_norm0_f5_f04.dat','r');
% stack=fread(fid,[1001 c*1],'real*4');
% fclose(fid);
% stack1t_f5_f04=stack;
% a=[430:470];
% b=[670:730];
% cmp410=stack1t_f04(350:600,lis);
% cmp660=stack1t_f04(600:800,lis);
% [cmpmax410,cmpt410]=max(stack1t_f04(a,lis));
% [cmpmax660,cmpt660]=max(stack1t_f04(b,lis));
% [cmpmax410,cmpt410]=max(stack1t_f04(a,lis));
% [cmpmax660,cmpt660]=max(stack1t_f04(b,lis));
% for i=1:200
%     for j=1:31
%     s410_f04(i,j)=stack1t_f04(cmpt410(j)+300+i,j);
%     s660_f04(i,j)=stack1t_f04(cmpt660(j)+600+i,j);
%     end
% end
% s410=sum(s410_f04');
% 
% plot(301:500,s410)


%2 this part is used for simply stacking diff bins
%%%%%%%%%%%%%%%%%%%for stack diff%%%%%%%%%%%%%
% % a=[50:140];
% a=[360:440];
% % a=[190:230];
% b=length(a);
% s1=sum(stack1t_f04(:,a)')./b;
% s2=sum(stack1t_f06(:,a)')./b;
% s3=sum(stack1t_f1(:,a)')./b;
% s4=sum(stack1t_f1p4(:,a)')./b;
% s5=sum(stack1t_f2(:,a)')./b;
% s6=sum(stack1t_f5(:,a)')./b;
% s7=sum(stack1t_f5_nofil(:,a)')./b;
%  s8=sum(stack1t_f5_kk(:,a)')./b;
% % s9=sum(stack1t_f5_f04(:,a)')./b;
% plot(0:0.1:100,s1','r')
% hold on
% plot(0:0.1:100,s2','g')
% plot(0:0.1:100,s3','y')
% plot(0:0.1:100,s4','b')
% plot(0:0.1:100,s5','m')
% hold on
% plot(0:0.1:100,s6','color',[0 0.5 0.5])
% plot(0:0.1:100,s7','color',[ 0.5 0 0.5])
%  plot(0:0.1:100,s8','color',[0.5 0.5 0.5])
%  legend('f5f02','f5f04','f5f06','f5f08','f5f1','f5f1p5','f5f2','f5f5')
% % plot(0:1000,s7','b')
% % axis([0 1000 -0.02 0.02])
% % legend('f5f02','f5f04','f5f1','f5f5')
% % figure(2)
% %  imagesc(0:2:1000,0:1:800,stack1t_f04(1:801,1:501*1))
% %   caxis([-0.02 0.02])70
% % % title('caxis([-0.05 0.05])')
% % ('distance(km)')
% xlabel('Amplitude')
% ylabel('Time(s)')
% % %  print -djpeg -r600 sc2_stack_f2_3hz_0001.jpg
%%%%%%%%%%%%%%%%end%%%%%%%%%%% 


%3 this part using for plot frofile of RFs 
% figure(8)
% % %  subplot(311)
% plotimag(stack1t_f02_kk(:,1:5:c),1,[0:200:1000],[0:1:1000],0.05)
% % subplot(211)
% dep660(1:501)=660;
% dep410(1:501)=410;
% % do1=1;
%  for ii=1:4
%   subplot(2,1,1)
% subplot(212)

% subplot(212)

% % % % % % %  sh=ii*10+90;70
% % % % % % %  sh=num2str(sh);
% % % % % % %  title(['baz' sh])
% % % % % % %   grid;
% % % % % % % caxis([-0.03 0.03])
%  axis([0 1400 0 70])
% % % % % % % do1=do1+c;
% hold on
% % plot(0:4:2100,dep660,'w--')
% % plot(0:4:2100,dep410,'w--')
% for i=1:6:c
%     plot([i i+3]*dx*4,[42 42],'k')
%      plot([i i+3]*4*dx,[62 62],'k')
% end
%  end
% title('CAL-F5)')
% title('Radial f0.03-0.5hz')
% xlabel('distance(km)')
% ylabel('time(s)')

% subplot(211)
%   imagesc(0:10:1600,0:1:700,stack1t_f02_kk(1:701,1:c1*1))
% % hold on
% caxis([-a a])
% % % % % % % % % % % % % % % % %  imagesc(0:dx:dx*(c-1),0:0.1:80,stack1t_f02_kk(1:801,1:c));
%  axis([300 1300 00 250])
% subplot(212)
prc=pro(1:5:4251);
  imagesc(1:1:c1,0:1:1000,stack1t_f03_kk(1:1001,1:c1*1))
% hold on
caxis([-a a])
% % % % % % % % % % % % % % % %  imagesc(0:dx:dx*(c-1),0:0.1:80,stack1t_f02_kk(1:801,1:c));
%  axis([102 111 00 100])
% 
% figure(3)
%  plotimag_gray(stack1t_f02_kk(:,1:dd:c),1,[1:dx*dd:dx*c],[0:1:1000],0.02)
% hold on
% plotimag_red(stack1t_f02_kk(:,1:dd:c),1,[1:dx*dd:c*dx],[0:1:1000],0.02)






% 
% axis([-100 1400 300 800])
% caxis([-0.005 0.005])
% %  title('f0.03-1.0hz   caxis([-0.03 0.03]) include s156&s157')
%  title('Transverse f0.03-0.5hz')
% xlabel('distance(km)')
% ylabel('time(s)')
%    axis([100 700 0 150])
%  print -djpeg -r600 sc2_stack_f2_3hz_0001_plotimag.jpg
% 
% 
% % % % % axis([0.5 196.5 300 750])
% % % % hold on
% % % % plot([46 46],[0 800],'k--')%%106 106
% % % % plot([56 56],[0 800],'k--')%%116 116
% % % % xlabel('bin index')
% % % % ylabel('time index')
% % % % title('f02, caxis([-0.0005 0.0005])','FontSize',10)
% % print -djpeg -r600 sc2_3hz_0.0001stack.jpg
% % % % 
% % % % plot((0:1858).*0.1-20,stack,'k')
% % % % hold on
% % % % plot((0:1858).*0.1-20,stack1,'b')