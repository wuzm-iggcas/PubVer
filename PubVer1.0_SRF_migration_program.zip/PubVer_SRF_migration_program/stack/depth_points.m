
clear
fid=fopen('depth1.dat','r');

cor=fscanf(fid,'%f ');
fclose(fid);

hang=size(cor);
hang=hang(1);
figure(7)

% set(gca,'view',[90 90])
% set(gca,'xDir','reverse');
hold on
fid=fopen('sc3_az65_dx2_norm0_f3_1_001_eqz_SsPp_profile.txt','r');

pro=fscanf(fid,'%f');
fclose(fid);

hang2=size(pro)
hang2=hang2(1);

plot(cor(1:4:hang),cor(2:4:hang),'b.');

fid=fopen('depth2.dat','r');

cor=fscanf(fid,'%f ');
fclose(fid);

hang=size(cor);
hang=hang(1);

plot(cor(1:4:hang),cor(2:4:hang),'m.');
 plot(pro(2:5:hang2),pro(1:5:hang2),'k.');
ylabel('lon')
xlabel('lat')
% legend('32km','66km')
set(gca,'view',[90 90])
set(gca,'xDir','reverse');


